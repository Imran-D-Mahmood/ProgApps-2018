import java.io.BufferedReader;
import java.io.FileInputStream;    
import java.io.IOException;    
import java.io.FileReader;
import java.util.Scanner;

public class JavaApplication {        
    public static void main(String[] args) throws IOException {
      
        Scanner scanner1 = new Scanner(new FileInputStream("C:/Users/Acer/Documents/Eclipse Workspace/JavaApplication/src/sample.txt"));
        Scanner kbd = new Scanner(System.in);
        boolean flag = false;
        String scan, busname;
        System.out.print("Enter terminal name: ");
        busname = kbd.next();

        while(scanner1.hasNext()) {
            scan = scanner1.next();
    
            
            if(busname.equalsIgnoreCase(scan) && busname.equalsIgnoreCase("dalinterminal") || busname.equalsIgnoreCase("dalin terminal") || busname.equalsIgnoreCase("dalin")) {
            	System.out.println("");
                try (BufferedReader br = new BufferedReader(new FileReader("C:/Users/Acer/Documents/Eclipse Workspace/JavaApplication/src/dalinterminal.txt"))) {
   					String line = null;
   					while ((line = br.readLine()) != null) {
       					System.out.println(line);
                                        }
                }

                flag = true;
                break;
            }  
            	else if(busname.equalsIgnoreCase(scan) && busname.equalsIgnoreCase("partasterminal") || busname.equalsIgnoreCase("partas terminal") || busname.equalsIgnoreCase("partas")) {
            	System.out.println("");
                try (BufferedReader br = new BufferedReader(new FileReader("C:/Users/Acer/Documents/Eclipse Workspace/JavaApplication/src/partasterminal.txt"))) {
   					String line = null;
   					while ((line = br.readLine()) != null) {
       					System.out.println(line);
                                        }
                }

                flag = true;
                break;
            }  if(busname.equalsIgnoreCase(scan) && busname.equalsIgnoreCase("victoryterminal") || busname.equalsIgnoreCase("victory terminal") || busname.equalsIgnoreCase("victory")) {
            	System.out.println("");
                try (BufferedReader br = new BufferedReader(new FileReader("C:/Users/Acer/Documents/Eclipse Workspace/JavaApplication/src/victoryterminal.txt"))) {
   					String line = null;
   					while ((line = br.readLine()) != null) {
       					System.out.println(line);
                                        }
                }

                flag = true;
                break;
            } else {
            	System.out.println("Terminal not found");
            	break;
            }

        }
       
    }
}