package javaapplication;

import java.io.BufferedReader;
import java.io.FileInputStream;    
import java.io.IOException;    
import java.io.FileReader;
import java.util.Scanner;

public class JavaApplication {        
    public static void main(String[] args) throws IOException {
      
        Scanner scanner1 = new Scanner(new FileInputStream("D:/Documents/NetBeansProjects/JavaApplication/src/sample.txt"));
        Scanner kbd = new Scanner(System.in);
        boolean flag = false;
        boolean scan, terminal;
        System.out.print("Enter terminal name: ");
        terminal = kbd.next();

        while(scanner1.hasNext()) {
            scan = scanner1.next();
    
            
            if(terminal.equalsIgnoreCase(scan) && terminal.equalsIgnoreCase("dalinterminal") || terminal.equalsIgnoreCase("dalin terminal") || terminal.equalsIgnoreCase("dalin")) {
            	System.out.println("");
                try (BufferedReader br = new BufferedReader(new FileReader("D:/Documents/NetBeansProjects/JavaApplication/src/dalinterminal.txt"))) {
   					String line = null;
   					while ((line = br.readLine()) != null) {
       					System.out.println(line);
                                        }
                }

                flag = true;
                break;
            }  
            	else if(terminal.equalsIgnoreCase(scan) && terminal.equalsIgnoreCase("partasterminal") || terminal.equalsIgnoreCase("partas terminal") || terminal.equalsIgnoreCase("partas")) {
            	System.out.println("");
                try (BufferedReader br = new BufferedReader(new FileReader("D:/Documents/NetBeansProjects/JavaApplication/src/partasterminal.txt"))) {
   					String line = null;
   					while ((line = br.readLine()) != null) {
       					System.out.println(line);
                                        }
                }

                flag = true;
                break;
            }  if(terminal.equalsIgnoreCase(scan) && terminal.equalsIgnoreCase("victoryterminal") || terminal.equalsIgnoreCase("victory terminal") || terminal.equalsIgnoreCase("victory")) {
            	System.out.println("");
                try (BufferedReader br = new BufferedReader(new FileReader("D:/Documents/NetBeansProjects/JavaApplication/src/victoryterminal.txt"))) {
   					String line = null;
   					while ((line = br.readLine()) != null) {
       					System.out.println(line);
                                        }
                }

                flag = true;
                break;
            } else {
            	System.out.println("Terminal not found");
            	break;
            }

        }
       
    }
}
