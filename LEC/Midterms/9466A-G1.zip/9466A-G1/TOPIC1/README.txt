Open this project using NetBeans IDE.
The program reads a .txt file. Replace the directory in the program, depending on the directory where the files are located in your own device.